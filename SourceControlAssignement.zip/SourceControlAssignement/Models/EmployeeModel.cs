﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using DataAnnotationsValidations.CustomValidation;
namespace DataAnnotationsValidations.Models
{
    public class EmployeeModel
    {
        [Required(ErrorMessage = "*First Name is Required!")]
        [RegularExpression("^[a-zA-Z]*$", ErrorMessage = "Only Alphabets and allowed.")]
        [StringLength(50, MinimumLength = 3, ErrorMessage="First Name must have atleast 3 Letters")]
        public string FName { get; set; }

        [Required(ErrorMessage="*Middle Name is Required!")]
        [RegularExpression(@"^[A-Z].*",ErrorMessage="Middle Name must start with a Capital case.")]
        public string MName { get; set; }

        [Required(ErrorMessage = "*Last Name is Required!")]
        [StringLength(50, MinimumLength=2, ErrorMessage = "Last Name must have atleast 2 Letters")]
        public string LName { get; set; }
        
        [Required(ErrorMessage = "*Email ID is Required")]
        [DataType(DataType.EmailAddress)]
        [MaxLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Incorrect Email Format")]
        public string Email { get; set; }

        [Required(ErrorMessage = "*Please select image.")]
        [FileExtensions(Extensions = "png,jpg,gif", ErrorMessage = "*Please upload valid format")]
        //[RegularExpression(@"([a-zA-Z0-9\s_\\.\-:])+(.png|.jpg|.gif)$", ErrorMessage = "Only Image files allowed.")]
        public HttpPostedFileBase PostedFile { get; set; }

        [Range(18.0,60.0, ErrorMessage="*Employee Age must be between 18-60")]
        public int age { get; set; }

        [Display(Name = "Date of birth")]
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "*Enter a Mobile Number")]
        [DataType(DataType.PhoneNumber,ErrorMessage="*Please enter a 10 digit Mobile Number.")]
        [Phone]
        public string MobilePhone { get; set; }

        [Required(ErrorMessage = "*Please enter hire date")]
        [Display(Name = "Hire Date")]
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        [CustomHireDate(ErrorMessage = "*Hire Date must be less than or equal to Today's Date")]
        public DateTime HireDate { get; set; }

        [DisplayName("Salary")]
        [Required(ErrorMessage = "*The Salary is required.")]
        [Range(10000, 20000)]
        [DisplayFormat(DataFormatString = "{0:#.####}")]
        public float Salary { get; set; }

        [Required(ErrorMessage = "*Password is Required.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "*Confirmation Password is Required")]
        [Compare("Password", ErrorMessage = "Password Must Match")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "*Please Select an Employee Designation")]
        [DisplayName("Employee Designation")]
        public Designation EmployeeDesignation { get; set; }
    }
    public enum Designation
    {
        Trainee,
        SoftwareEngineer,
        SoftwareAnalyst,
        DatabaseManager
    }
}