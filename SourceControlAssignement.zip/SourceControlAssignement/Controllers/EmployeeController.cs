﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAnnotationsValidations.Models;
using System.IO;
namespace DataAnnotationsValidations.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        public ActionResult Index()
        {
            return View("Index");
        }
       
        [HttpPost]
        public ActionResult EmployeeCheck(EmployeeModel sm, HttpPostedFileBase postedFile)
        {
            
            string path = Server.MapPath("~/Uploads/");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            if (postedFile != null)
            {
                string fileName = Path.GetFileName(postedFile.FileName);
                postedFile.SaveAs(path + fileName);
                ViewBag.Message += string.Format("<b>{0}</b> uploaded.<br />", fileName);
            }
            if (ModelState.IsValid)
            {
                ViewBag.FName = sm.FName;
                ViewBag.MName = sm.MName;
                ViewBag.LName = sm.LName;
                ViewBag.Email = sm.Email;
                ViewBag.age = sm.age;
                ViewBag.DateOfBirth = sm.DateOfBirth;
                ViewBag.sm.EmployeeDesignation = sm.EmployeeDesignation;
                ViewBag.MobilePhone = sm.MobilePhone;
                ViewBag.HireDate = sm.HireDate;
                ViewBag.Salary = sm.Salary;
                return View("Index");
            }
            else
            {
                ViewBag.FName =
                    ViewBag.MName = "No Data";
                    ViewBag.LName = "No Data";
                    ViewBag.Email = "No Data";
                    ViewBag.age = "No Data";
                    ViewBag.DateOfBirth = "No Data";
                    //ViewBag.sm.EmployeeDesignation = "No Data";
                    ViewBag.MobilePhone = "No Data";
                    ViewBag.HireDate = "No Data";
                    ViewBag.Salary  = "No Data";
        
                return View("Index");
            }
        }
        
    }
    }

